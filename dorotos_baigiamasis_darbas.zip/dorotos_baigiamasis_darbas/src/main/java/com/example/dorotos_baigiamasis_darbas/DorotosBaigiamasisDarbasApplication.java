package com.example.dorotos_baigiamasis_darbas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DorotosBaigiamasisDarbasApplication {

	public static void main(String[] args) {
		SpringApplication.run(DorotosBaigiamasisDarbasApplication.class, args);
	}

}

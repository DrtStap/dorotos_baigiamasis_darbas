package com.example.dorotos_baigiamasis_darbas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DorotosBaigiamasisDarbasApplicationTests {

	@Test
	void contextLoads() {
	}

}
